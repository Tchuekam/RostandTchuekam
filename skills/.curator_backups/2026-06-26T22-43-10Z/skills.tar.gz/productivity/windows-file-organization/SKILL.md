---
name: windows-file-organization
title: Windows File Organization
description: Organize messy Windows Desktop/Downloads/Documents folders into clean categories. Audit, classify, create folders, move files, and report observations to the user.
category: productivity
tags:
  - windows
  - file-management
  - desktop-organization
  - cleanup
trigger: user asks to organize, clean up, tidy, sort, or classify files on their Desktop, Downloads, or Documents folder; OR user says make space, C is full, move to H, free up space, what can I move, or storage is full.
---

# Windows File Organization

Organize a chaotic folder into clean categorized subdirectories. Designed for non-technical Windows users.

## Workflow

### 1. Scan — List all items

Use `terminal` with `ls -la` on Windows git-bash:

```bash
ls -la "/c/Users/$USER/Desktop"
```

For Downloads/Documents:

```bash
ls -la "/c/Users/$USER/Downloads"
ls -la "/c/Users/$USER/Documents"
```

**Note**: In git-bash on Windows, use `/c/Users/CLINIC/...` paths (MSYS-style), not `C:\...`.

### 2. Classify each item into categories

Standard category scheme (adapt per user):

| # | Category | Contents |
|---|---|---|
| 01-DOCUMENTS | .docx, .xlsx, .txt, .pdf — general documents |
| 02-PROJECTS-TCHUEKAM | Anything related to TCHUEKAM, marketing, branding, product |
| 03-MARKETING-COM | Marketing collateral, logos, chatbots research |
| 04-SCRIPTS-CODE | .js, .py, .sh, .bat, code files |
| 05-BUSINESS-CLIENTS | Client folders, business partner documents |
| 06-RACCOURCIS | .lnk files (shortcuts) |
| 07-DOWNLOADS-ARCHIVES | Downloads, .zip, .rar archives |
| 08-WEB-RESEARCH | Bookmarks, research notes, saved articles |

**Preserve existing folders** — don't move them. Only reorganize loose files.

### 3. Create category directories

```bash
cd "/c/Users/CLINIC/Desktop"
mkdir -p "01-DOCUMENTS" "02-PROJECTS-TCHUEKAM" "03-MARKETING-COM" \
         "04-SCRIPTS-CODE" "05-BUSINESS-CLIENTS" "06-RACCOURCIS" \
         "07-DOWNLOADS-ARCHIVES" "08-WEB-RESEARCH"
```

### 4. Move files into categories

Use `mv` with numbered prefixes. Files that fail to move (locked/open) leave a clear note.

```bash
mv "SomeFile.docx" "01-DOCUMENTS/"
mv "project-file.js" "04-SCRIPTS-CODE/"
```

### 5. Handle locked files gracefully

- **`~$` (tilde-dollar) files** = temporary Office lock files. They disappear when the user closes the app. Don't fight them.
- **Files open in an editor** (Word, VS Code) = cannot be moved. Tell the user to close the app and offer to retry.
- **Leave `desktop.ini` alone** — Windows system file.

### 6. Report — deliver a structured summary

Give the user:

1. **What was created**: table of folders with contents
2. **What didn't move**: which files and why
3. **Observations**: patterns you noticed (many marketing files, heavy images, duplicate files, working style insights)

### 7. Duplicate scan — lightweight approach

When the user asks for duplicate cleanup AFTER the initial organization:

1. **Do NOT scan full Desktop recursively** — the `wacrm/node_modules` directory alone can cause a 300s+ timeout.
2. **Exclude heavy directories upfront**: `node_modules/`, `.git/`, `HOMEAPPS/`, `MYFOLDER/`, `LuckyTechHub-Bot-main/` — they rarely produce actionable user-facing duplicates.
3. **Use `md5sum`** (available in git-bash) with `sort | uniq -d`:
   ```bash
   find . -type f -not -name 'desktop.ini' -not -name '~$*' \
     -not -path './*/node_modules/*' -not -path './*/.git/*' \
     -size +1k -exec md5sum {} \; 2>/dev/null | sort > /tmp/scan.txt
   awk '{print $1}' /tmp/scan.txt | sort | uniq -d
   ```
4. **If the scan takes >30s, delegate it** — the user will get impatient. Use `delegate_task` with a subagent that has `terminal`+`file` toolsets.
5. **Report clearly**: "No duplicates found" or list the duplicate files with paths and sizes.
6. **Never delete duplicates without user confirmation** — some "duplicates" may be intentional (e.g., same file organized in two categories).

### 8. Save the category scheme to memory

Record the folder structure and any user-specific preferences (e.g., "don't touch MYFOLDER") to memory so future sessions know the layout.

## Disk Space Analysis & External Drive Migration

When the user's C: drive is critically full (90%+) and they want to move data to an external drive (H:, etc.), follow this diagnostic-first workflow.

### Trigger Tokens
User says: "make space", "C: is full", "move to H:", "free up space", "what can I move", "storage is full".

### 1. Check drive status first

```bash
df -h /c/ /h/ /d/
```

Note: the 99% full C: causes `du -sh` on any large folder to time out (30-60s+). Do NOT rely on `du -sh` for the initial scan — use alternative fast probes.

### 2. Fast-diagnose top space consumers (when du is too slow)

When standard `du` commands time out on a choked disk, use these lightweight probes instead:

| Probe | Command | What it finds |
|---|---|---|
| Check node_modules | `ls /c/Users/$USER/node_modules/ 2>/dev/null \| wc -l` | How many packages (each may be GBs) |
| Check Temp | `ls /c/Users/$USER/AppData/Local/Temp/ 2>/dev/null | wc -l` | Temp files count |
| Check caches | Check if `.cache/`, `.cargo/`, `.bun/`, `.codex/`, `.gemini/` exist under `$HOME` | Large tool caches |
| Check Windows Temp | `ls /c/Windows/Temp/ 2>/dev/null | wc -l` | System temp |
| Check big user dirs | Try `du -sh` on Desktop, Downloads, Documents, Videos, Pictures individually with 30s timeout | Identify which user folder is heavy |

### 3. Prioritize what to move

**TIER 1 — Safe to move to H: (no side effects):**
- Desktop personal files (not shortcuts to installed programs)
- Downloads full of installers, ISOs, zips
- Videos, large Pictures, Music folders
- Old project folders you cloned but don't actively use
- OneDrive (if you don't need offline sync of everything)

**TIER 2 — Safe to MOVE but need path configuration after:**
- `node_modules/` (can be moved but npm/pnpm need `--prefix` or symlink)
- `.cargo/` (can set CARGO_HOME to H:)
- `.bun/` (can set BUN_INSTALL to H:)
- `.cache/` (various caches — npx, pip, etc.)

**TIER 3 — Cleanup instead of move (delete):**
- `C:\Windows\Temp\` — safe to delete everything inside
- `C:\Users\$USER\AppData\Local\Temp\` — safe to delete everything inside
- Browser caches (can be cleaned via browser settings)
- `C:\hiberfil.sys` — if user doesn't use hibernate: `powercfg -h off` (frees RAM-size GBs)

### 4. For each tier, say the expected space gain

Don't just list folders — estimate. User needs to know: "moving videos saves ~5GB", "cleaning Temp saves ~1GB".

### 5. Check external drive capacity

Before recommending moves, check: `df -h /h/` or `ls /h/` to see what's already on H:. Don't suggest overwriting existing folders (apps/, down/, WEBAPPS/, etc.).

### 6. Execute moves

Use `mv` for simple files/folders:
```bash
mv "/c/Users/CLINIC/Videos" "/h/Videos"
```

For Tier 2 items that need path reconfiguration, explain the env var change. Don't do it automatically — ask the user if they want to proceed.

### 7. Report

Give a clean table:
| Action | Item | Est. Space Freed |
|---|---|---|
| MOVE to H: | Videos/ | ~5 GB |
| MOVE to H: | Downloads/ | ~3 GB |
| DELETE | Windows Temp | ~500 MB |
| TOTAL | | ~8.5 GB |

## Pitfalls

- **~$ files**: These are Office temp/lock files. They look like duplicates (e.g. `~$ocument.docx`). **Do not try to move or delete them** — they are created by Word while a document is open and vanish on their own.
- **git-bash path syntax**: Use `/c/Users/CLINIC/...` not `C:\\Users\\CLINIC\\...` in terminal commands.
- **.lnk files are NOT the actual programs**: They are shortcuts. Collect them in a RACCOURCIS folder, don't delete them.
- **User may have many .docx open simultaneously** — check for locked files by attempting the mv; if it fails, note it and move on.
- **Don't delete anything unless asked** — the user may want files you consider clutter.
- **Use `mv` (not `cp`)** — moving is faster and doesn't leave originals.
- **Prefix category folders with numbers** (01-, 02-) so they sort in a logical order in Windows File Explorer.
- **Always ask for exclusions before mass moves**: Before executing a bulk data migration, list the items you plan to move and ask the user: "What should I NOT touch?" Users have specific folders (raccourcis, home shortcuts, active bots, CRM projects) they want kept on C:. Move first, ask later = frustration and manual recovery.
- **Inter-device `mv` is actually copy+delete**: Moving from C: to H: (different physical drives) means Windows copies then deletes. It's slow and can fail with "Directory not empty" when the target has a folder with the same name. To handle this: (a) list target dir on H: first and check for conflicts, (b) rename source or target to avoid collisions (e.g. `WEBAPPS_DESKTOP`), (c) expect timeouts on folders >1GB and use background processes or robocopy instead.
- **Locked executables in Downloads**: A running `.exe` installer file in Downloads cannot be moved until the process exits. Check with `handle.exe` or just note the locked file and move on — retry after reboot.
- **Heavy folders cause 120s+ timeout**: Videos/, Pictures/, node_modules/ are common culprits. Break the migration into batches: move smaller folders first, then tackle heavy ones one at a time with background terminal + notify_on_complete. Never run concurrent heavy mv commands — they saturate the disk and freeze the terminal.

## Reference Files

- `references/desktop-organization.md` — prior Desktop organization session: category mapping, locked files, observations
- `references/external-drive-migration.md` — C:→H: migration session: pitfalls, exclusions, timeout handling, name collision fix
