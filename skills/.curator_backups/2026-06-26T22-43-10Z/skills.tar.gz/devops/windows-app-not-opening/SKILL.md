---
name: windows-app-not-opening
description: "Windows troubleshooting for non-technical users: diagnose why apps won't open, and identify/remove resource-hogging applications."
version: 1.3.0
author: TCHUEKAM (Giantect Empire)
metadata:
  hermes:
    tags: [windows, troubleshooting, app-crash, electron, process, shortcut]
    related_skills: [systematic-debugging]
platforms: [windows]
---

# Windows App Won't Open — Diagnosis Pipeline

## When to Use

User reports: "I clicked the icon but nothing happens" / "app won't open" / "it's not starting" / "I double-clicked many times, nothing appears."

This covers:
- Desktop shortcuts that appear to do nothing
- Apps that launch in Task Manager but no window shows
- Apps that crash silently (no error dialog)
- Electron apps that fail due to network/DNS dependency

## Pipeline (ordered — run these steps in sequence, stop when you find root cause)

### Step 1: Locate the Shortcut

Use `tchuekam_index_search(query="appname")` first (sub-50ms).

If no index result, check the Desktop with:
```
ls -la /c/Users/CLINIC/Desktop/ | grep -i <appname>
```

### Step 2: Read the Shortcut Target

Desktop icons are `.lnk` files. Use PowerShell's COM object to read them:

```
powershell -Command "
\$shell = New-Object -ComObject WScript.Shell
\$shortcut = \$shell.CreateShortcut('C:\Users\CLINIC\Desktop\<AppName>.lnk')
Write-Output \"Target: \$(\$shortcut.TargetPath)\"
Write-Output \"Args: \$(\$shortcut.Arguments)\"
Write-Output \"WorkDir: \$(\$shortcut.WorkingDirectory)\"
"
```

This tells you:
- The actual `.exe` path
- Working directory
- Any command-line arguments

### Step 3: Verify the Executable Exists

```
ls -la "/c/Users/CLINIC/AppData/Local/Programs/<AppName>/"
```

If the folder/file is missing → app was uninstalled or the shortcut is orphaned.
If it exists → check the file size (0 bytes = corrupt).

### Step 4: Detect App Type (optional but useful)

Look for signature files in the install directory:
- `chrome_100_percent.pak`, `icudtl.dat`, `v8_context_snapshot.bin` → **Electron app**
  - Electron apps are essentially Chromium browsers. They often fail silently on network errors.
- `.class` files or `lib/` with jar files → Java app (needs JRE)
- UWP-style folder names (e.g. `Microsoft.SomeApp`) → Store app

### Step 5: Kill Stale Processes and Launch Fresh

```
powershell -Command "Get-Process <AppName> -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue"
```

Then launch a fresh instance:
```
powershell -Command "Start-Process -FilePath '<full exe path>' -WindowStyle Normal"
```

### Step 6: Check for Window

```
Start-Sleep 8
Get-Process <AppName> | Format-Table Id, ProcessName, MainWindowTitle, Responding -AutoSize
```

- **MainWindowTitle is empty** → process is running but window is hidden, off-screen, or crashed before rendering.
- **Multiple <AppName> processes** → user double-clicked many times. Stale zombies accumulating.
- **No process** → exe crashes immediately (corrupt binary, missing DLL).

### Step 7: Bring Hidden Window to Front (if processes exist with no visible window)

```
Add-Type @' 
using System; 
using System.Runtime.InteropServices; 
public class Win32 { 
    [DllImport("user32.dll")] 
    public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow); 
    [DllImport("user32.dll")] 
    public static extern bool SetForegroundWindow(IntPtr hWnd); 
} 
'@; 
[Win32]::ShowWindowAsync($pid_handle, 1); 
[Win32]::SetForegroundWindow($pid_handle)
```

### Step 8: Read App Logs (electron apps)

Electron stores logs at:
```
~/AppData/Roaming/<AppName>/logs/
```

- `main.log` — main process logs (auto-updater, app lifecycle)
- `language_server.log` — plugins/extensions (common crash source)

Look for these patterns:

| Log Pattern | Meaning |
|---|---|
| `ERR_INTERNET_DISCONNECTED` | No network. App is cloud-dependent (IDX, Gemini, etc.) |
| `ERR_NAME_NOT_RESOLVED` | DNS failure. Can't reach auth/API servers. |
| `ERR_NETWORK_IO_SUSPENDED` | Machine was in sleep/hibernate, network stack not restored. |
| `dial tcp: lookup X: no such host` | DNS can't resolve. Google APIs are common for cloud tools. |
| `Failed to get OAuth token` | Authentication failed — often because network was down at startup. |

### Step 8.5: Binary Won't Execute — Zero-Process Case

When you call `Get-Process <AppName>` after launch and get **nothing** (no process at all), the executable failed to load at the OS level. This is different from a crash — the PE loader itself rejected the binary.

**Diagnosis signs:**
- `ProcessName` column in `Get-Process` is completely absent after launch
- No window, no error dialog, no crash event in Windows Application log
- `stderr` redirection produces zero output (empty file)
- `file` command shows `PE32+ executable` but the binary silently exits with code 0
- The app's own log files don't update (the process died before any logger initialised)

#### Sub-step 8.5a: Verify PE Loadability

Check if the binary even responds to `--help` or `--version`:
```
cmd.exe /c ""<full_exe_path> --version"
```
If zero output → the CRT entry point doesn't fire. Three likely causes:

1. **Missing Visual C++ redistributable** — Electron apps bundle `d3dcompiler_47.dll`, `vulkan-1.dll`, etc., but depend on system `VCRUNTIME140.dll`. Check with:
   ```
   cmd.exe /c "where vcruntime140.dll"
   ```
2. **Corrupted binary** — the PE header or first section is damaged. Check file size vs. original (compare with the installer's expected size or a fresh download).
3. **Kernel-locked file** — `app.asar` (Electron) or other resources held by the Windows file system cache, Windows Search Indexer, or Windows Defender real-time scanning. `rm -f` returns "Device or resource busy" even after killing all user processes. This requires a reboot or an `rmdir` from a different boot session.

#### Sub-step 8.5b: Attempt Fresh Download + Reinstall

If the binary is confirmed corrupt (won't execute, correct size but no output):

1. **Find the download URL** for the same version from the vendor's website (the installed version is often shown in logs or `app-update.yml`).
2. **Download manually** with `curl -L -o` to a known location.
3. **Verify size** — if the fresh download is significantly smaller (e.g. 137MB vs 213MB), it may be a web installer, not the full binary.
4. **Run the installer** — some installers are NSIS-based and silently skip overwriting when the same version is detected. In that case, the old corrupt binary remains. The fix requires removing the install directory first (but ask the user before deleting).
5. **Check for blocking processes** — a stale `lockfile` or `SingletonLock` in the app's `AppData/Roaming` directory can prevent the Electron shell from starting. Remove stale lock files:
   ```
   rm -f "<AppData>/lockfile" "<AppData>/SingletonSocket" "<AppData>/SingletonLock"
   ```

#### Sub-step 8.5c: Electron App — Verify .asar Integrity

Electron apps pack their JS code in `resources/app.asar`. If the asar is truncated:
```
ls -la "<install_dir>/resources/app.asar"
```
If it's 0 bytes or suspiciously small, the renderer process will start but exit immediately. Check by extracting:
```
npx asar extract "<install_dir>/resources/app.asar" /tmp/check
ls /tmp/check/package.json   # Should have "main": "dist/main.js"
```

#### Sub-step 8.5d: Fallback — Use the Web / CLI Version

If the desktop IDE binary won't run and reinstall isn't possible (user blocked deletion, same-version installer skips overwrite):

1. Check if the app has a **web version** — open the vendor's domain in a browser.
2. Check if it has a **CLI tool** — install via their install script (PowerShell/CMD) or download the binary directly from the vendor's manifest API.
3. Check if a **language server / backend** bundled with the app can start independently (some Electron apps ship a standalone Go/C++ backend that runs fine without the GUI).

#### Sub-step 8.5e: NSIS Installer Also Fails

When the NSIS installer itself can't execute, the problem is at the Windows subsystem level — the installer's embedded NSIS engine can't decompress. This manifests as:
- The installer exits silently (exit code 0) with zero files written
- The target folder may get a partial `resources/` skeleton created but no actual files
- `file` shows "Nullsoft Installer self-extracting archive" but the binary doesn't start

**Workarounds:**
1. Use `7z x` or other archiver to extract the NSIS installer data manually.
2. Try the `_?=<targetdir>` NSIS switch with `/NCRC` to disable CRC check: `installer.exe /NCRC /S _?=C:\Path`
3. Install the app's **CLI** binary instead (often distributed as a separate Go/Rust binary that doesn't need NSIS).
4. Use the **web version** in a browser.

### Step 9: Verify Network (when app is cloud-dependent)

```
powershell -Command "Test-Connection -ComputerName 8.8.8.8 -Count 1 -Quiet"
powershell -Command "Resolve-DnsName google.com -QuickTimeout -ErrorAction SilentlyContinue | Select-Object Name,IPAddress"
```

If DNS fails → restart DNS or check internet. Many cloud apps (IDX, Google Cloud Code, Gemini, Copilot) simply won't render anything without connectivity.

## Pitfalls

- **Ping with `-c` flag requires admin** on Windows. Use `Test-Connection -Count 1 -Quiet` in PowerShell instead.
- **Stale zombie processes** accumulate when user clicks the icon rapidly. Kill them ALL before retrying.
- **Electron apps don't show error dialogs** — they fail silently in logs. Always check `main.log`.
- **Multiple process instances** after clicking repeatedly: the app may be running already but hidden behind other windows or off-screen.
- **COM Object for .lnk reading only works on actual shortcuts**, not UWP app tiles or pinned Taskbar shortcuts.
- **Kernel-locked files** — `app.asar` in Electron apps can be locked by the Windows file system cache, not by a user process. `rm -f` returns "Device or resource busy" even with zero matching processes. Neither `taskkill`, `Stop-Process -Force`, nor `Remove-Item -Force` will unlock it. The fix is a **reboot**, or booting into Safe Mode to delete.
- **NSIS installer skips same-version** — when the installed version matches the installer's version, NSIS silently exits without replacing any files. The corrupt binary survives. Must delete install directory first (requires reboot if kernel-locked) or use the `_?=` switch (which doesn't always work).
- **NSIS installer silently fails** — the NSIS decompression engine itself may not work on a machine with PE loading issues. `file` shows the installer as a valid NSIS archive but running it produces zero effect. Try extracting with `7z x` or using a different deployment method (CLI, web, portable ZIP).
- **No registry entry ≠ app not present** — some apps install portably (no MSI, no Windows Installer registration). `wmic product` won't find them. Check `AppData\Local\Programs\<AppName>\` directly.
- **Uninstall.exe is also an Electron binary** — if the main app's binary is corrupt, the bundled `Uninstall <AppName>.exe` likely shares the same Electron shell and is also broken. Don't rely on it.

## Related: Performance Diagnosis & Software Removal

This skill also covers **Windows performance troubleshooting** for non-technical users. When a user reports "my computer is slow", use the same investigation-first approach:

1. **Identify top RAM consumers** — `Get-Process | Sort-Object WorkingSet64 -Descending`
2. **Report findings** and let the user decide what to remove
3. **Kill processes** before uninstalling
4. **Find install via registry** (both HKCU and HKLM)
5. **Run official uninstaller**, then wipe residual files (models, configs, caches)
6. **Verify deletion** and show before/after RAM recovery

## References

- `references/antigravity-session-2026-05-27.md` — diagnosing a Google Cloud Code (Antigravity) Electron app that refused to open due to internet/DNS failures
- `references/antigravity-binary-wont-execute-2026-05-27.md` — harder case: binary won't start at all (zero process, no log, no crash event). PE loader failure diagnosis and recovery.
- `references/antigravity-reinstall-attempt-2026-05-27.md` — NSIS installer also fails silently, kernel-locked app.asar blocks deletion, CLI installed as fallback.
- `references/performance-removal-session-2026-05-27.md` — full worked example: user reported slow PC, identified LM Studio as 5.4 GB RAM hog, complete clean uninstall with residual wipe
