---
name: windows-agent-deployment
description: "Framework for packaging, securing, and distributing Windows-based agent applications."
---

# Windows Agent Deployment

This skill governs the end-to-end process of packaging, securing, and deploying autonomous AI agents on Windows environments.

## Deployment Pipeline

### 1. Security & Hardening
- **Obfuscation:** Use `PyInstaller` with `--key` (AES encryption) to obscure Python bytecode.
- **Credential Protection:** Store sensitive API keys in the Windows Credential Manager API, not `.env` files.
- **Policy Engine:** Integrate `tirith` or Pydantic-based guardrails into the agent's core loop to prevent unauthorized tool use.
- **Code Signing:** Use `signtool` for production binaries.

### 2. Telemetry & Activation (The "Phone Home" Protocol)
- **Identity:** Use WMI (`Win32_BaseBoard.SerialNumber`) for stable machine-ID generation.
- **Activation:** Implement a bootstrap shim (`bootstrap.py`) that performs a handshake with a licensing server (JWT-based) before spawning the agent.
- **Analytics:** Integrate `posthog` for usage tracking (captures: `app_installed`, `version`, `os`).

### 3. Packaging & Distribution
- **Requirements:** Bundle all dependencies (`flask`, `pyjwt`, `requests`, `wmi`, `posthog`, `hermes-agent`) into a `requirements.txt`.
- **Packaging:** Use `PyInstaller` (`--onefile`) to create a standalone `.exe`.
- **Installation:** Use `Inno Setup` for the final Windows installer package.

## References
- `scripts/setup-licensing-service.py` (Flask skeleton)
- `scripts/telemetry-hook.py` (PostHog integration)
- `templates/bootstrap.py` (Activation and spawn logic)

## Pitfalls
- **WMI Permissions:** Accessing hardware identifiers may require specific execution contexts.
- **Dependency Bloat:** Minimize bundled packages to keep the `.exe` size manageable.
- **Startup Latency:** Licensing checks add delay. Use async requests if the agent loop initialization allows it.
